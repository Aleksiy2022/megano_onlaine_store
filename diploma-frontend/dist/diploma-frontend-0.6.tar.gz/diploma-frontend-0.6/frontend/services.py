class GetAdminSettings:
    """
    Получение административных настроек.
    """
    pass


class GetListViewedProducts:
    """
    Сервис получение списка просмотренных товаров.
    """
    pass


class AddingProductToTheCart:
    """
    Сервис добавление товара в карзину.
    """
    pass


class AddingReviewToTheProduct:
    """
    Сервис добавление отзыва продукту.
    """
    pass


class Payment:
    """
    Сервис оплаты.
    """
    pass

